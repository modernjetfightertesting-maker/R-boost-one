package com.honq.boost

import android.animation.ObjectAnimator
import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView

class IntroActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var done = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG

        val root = FrameLayout(this).apply { setBackgroundColor(Ui.BG) }

        val title = Ui.title(this, "HONQ/BOOST", 26f)
        root.addView(title, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.START
        ).apply { leftMargin = Ui.dp(this@IntroActivity, 28); topMargin = Ui.dp(this@IntroActivity, 70) })

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            alpha = 0f
            scaleX = 0.7f
            scaleY = 0.7f
        }
        root.addView(logo, FrameLayout.LayoutParams(
            Ui.dp(this, 260), Ui.dp(this, 160), Gravity.CENTER
        ))

        val msg = Ui.label(this, "Preparing this device on game mode,\nplease wait to full access", 14f, 0xFF3A4D7A.toInt()).apply {
            gravity = Gravity.CENTER
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        }
        root.addView(msg, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM
        ).apply { bottomMargin = Ui.dp(this@IntroActivity, 90) })

        setContentView(root)

        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(1200).start()
        handler.postDelayed({
            // kilau: logo berdenyut sekali
            ObjectAnimator.ofFloat(logo, "alpha", 1f, 0.55f, 1f).apply {
                duration = 900
                interpolator = LinearInterpolator()
                start()
            }
        }, 1400)

        root.setOnClickListener { next() }
        handler.postDelayed({ next() }, 3500)
    }

    private fun next() {
        if (done) return
        done = true
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
