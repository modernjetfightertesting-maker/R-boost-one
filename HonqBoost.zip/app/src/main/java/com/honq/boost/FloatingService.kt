package com.honq.boost

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

class FloatingService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private val handler = Handler(Looper.getMainLooper())

    private var panel1: View? = null
    private var panel2: View? = null
    private var lp2: WindowManager.LayoutParams? = null

    private var frames = 0
    private var fps = 0

    private lateinit var batTxt: TextView
    private lateinit var batBar: ProgressBar
    private lateinit var ramLabel: TextView
    private lateinit var ramBar: ProgressBar
    private lateinit var gpuTv: TextView
    private lateinit var fpsTv: TextView
    private lateinit var ramTv: TextView
    private lateinit var celTv: TextView
    private var gauge: GaugeView? = null
    private var gaugeTv: TextView? = null

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frames++
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            update()
            handler.postDelayed(this, 1000)
        }
    }

    private fun d(v: Int) = Ui.dp(this, v)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel1 != null) return START_STICKY
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izin 'Tampil di atas app lain' belum aktif", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        startFg()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager

        val v = buildPanel1()
        val lp = params(d(300), d(20), d(80))
        wm.addView(v, lp)
        drag(v, lp)
        panel1 = v

        Choreographer.getInstance().postFrameCallback(frameCb)
        handler.post(ticker)
        return START_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("honq", "HONQ BOOST", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "honq")
            .setContentTitle("HONQ/BOOST aktif")
            .setContentText("Floating window sedang berjalan")
            .setSmallIcon(R.drawable.logo)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun params(w: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        w,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        this.x = x
        this.y = y
    }

    private fun drag(v: View, lp: WindowManager.LayoutParams) {
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt()
                    lp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(v, lp)
                    true
                }
                else -> false
            }
        }
    }

    // ---------------- Floating window 1 ----------------
    private fun buildPanel1(): View {
        val c: Context = this
        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.panelBg(c)
            setPadding(d(14), d(10), d(14), d(12))
        }

        val head = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.title(c), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(Ui.label(c, "✕", 18f).apply {
            setPadding(d(10), 0, d(4), 0)
            setOnClickListener { stopSelf() }
        })
        root.addView(head)

        batTxt = Ui.label(c, "BAT --%", 11f)
        Ui.add(root, batTxt, 6)
        batBar = Ui.bar(c)
        root.addView(batBar, Ui.matchW(d(8)))

        ramLabel = Ui.label(c, "RAM --%", 11f)
        Ui.add(root, ramLabel, 6)
        ramBar = Ui.bar(c)
        root.addView(ramBar, Ui.matchW(d(8)))

        // shortcut app
        val apps = LinearLayout(c).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, d(10), 0, d(6))
        }
        val pkgs = listOf("com.whatsapp", "com.google.android.youtube", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill")
        for (pkg in pkgs) {
            try {
                val icon = packageManager.getApplicationIcon(pkg)
                val iv = ImageView(c).apply {
                    setImageDrawable(icon)
                    setOnClickListener {
                        packageManager.getLaunchIntentForPackage(pkg)?.let { i ->
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(i)
                        }
                    }
                }
                apps.addView(iv, LinearLayout.LayoutParams(d(44), d(44)).apply { rightMargin = d(10) })
            } catch (e: PackageManager.NameNotFoundException) {
            }
        }
        if (apps.childCount == 0) apps.addView(Ui.label(c, "Shortcut app: belum ada app terpasang", 11f, Ui.SOFT))
        root.addView(apps)

        gpuTv = Ui.label(c, "GPU N/A", 14f)
        root.addView(gpuTv)

        root.addView(Ui.label(c, "GAME MODE SETTING", 13f).apply { setPadding(0, d(8), 0, d(2)) })
        root.addView(Ui.toggle(c, "AUTO PANEL CONTROL GYRO") { toast("Auto Panel Control Gyro: ${onOff(it)} (uji coba)") })
        root.addView(Ui.toggle(c, "BOOST UP FPS GAME TURBO SMART PANEL CONTROL") {
            if (it) toast("RAM dibersihkan: ${Stats.cleanRam(c)} app") else toast("Boost: OFF")
        })
        root.addView(Ui.toggle(c, "GYRO DINAMIC POWRED STABILITY") { toast("Gyro Dinamic: ${onOff(it)} (uji coba)") })
        root.addView(Ui.toggle(c, "AKTIFKAN MODE EKTERNAL") { if (it) showPanel2() else hidePanel2() })

        fpsTv = Ui.label(c, "FPS:--", 18f)
        ramTv = Ui.label(c, "RAM:--", 18f)
        celTv = Ui.label(c, "CEL:--", 18f)
        Ui.add(root, fpsTv, 8)
        root.addView(ramTv)
        root.addView(celTv)

        // volume
        root.addView(Ui.label(c, "VOL", 12f, Ui.SOFT).apply { setPadding(0, d(8), 0, 0) })
        val maxVol = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        root.addView(Ui.seek(c, maxVol, audio.getStreamVolume(AudioManager.STREAM_MUSIC)) { p, user ->
            if (user) audio.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0)
        })

        // kecerahan
        root.addView(Ui.label(c, "KEC", 12f, Ui.SOFT))
        val curBr = try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        } catch (e: Exception) {
            128
        }
        root.addView(Ui.seek(c, 255, curBr) { p, user ->
            if (user) setBrightness(p)
        })

        return root
    }

    private fun setBrightness(v: Int) {
        if (Settings.System.canWrite(this)) {
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, v.coerceIn(1, 255))
        } else {
            toast("Aktifkan izin 'Ubah pengaturan sistem' dulu")
            startActivity(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    // ---------------- Floating window 2 ----------------
    private fun showPanel2() {
        if (panel2 != null) return
        val v = buildPanel2()
        val lp = params(d(250), d(330), d(80))
        wm.addView(v, lp)
        drag(v, lp)
        panel2 = v
        lp2 = lp
    }

    private fun hidePanel2() {
        panel2?.let { wm.removeView(it) }
        panel2 = null
        gauge = null
        gaugeTv = null
    }

    private fun buildPanel2(): View {
        val c: Context = this
        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.panelBg(c, 28)
            setPadding(d(16), d(14), d(16), d(14))
        }

        val top = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        val g = GaugeView(c)
        gauge = g
        top.addView(g, LinearLayout.LayoutParams(d(96), d(96)))
        val gt = Ui.label(c, "-- fps", 22f, 0xFFFFFFFF.toInt()).apply { setPadding(d(12), 0, 0, 0) }
        gaugeTv = gt
        top.addView(gt)
        root.addView(top)

        var gpuLimit = 80
        val gpuLabel = Ui.label(c, "$gpuLimit% max gpu", 13f)
        Ui.add(root, gpuLabel, 10)
        root.addView(Ui.seek(c, 50, gpuLimit - 50) { p, user ->
            if (user) {
                gpuLimit = p + 50
                gpuLabel.text = "$gpuLimit% max gpu"
            }
        })

        root.addView(Ui.toggle(c, "BYPASS CHARG GT OJR") { toast("Bypass Charging: ${onOff(it)} (uji coba)") })
        root.addView(Ui.toggle(c, "GYRO DINAMIC EKTERNAL") { toast("Gyro Dinamic Eksternal: ${onOff(it)} (uji coba)") })
        root.addView(Ui.toggle(c, "DIABLO MODE") { toast("Diablo Mode: ${onOff(it)} (uji coba)") })

        val over = LinearLayout(c).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, d(8), 0, 0)
        }
        over.addView(Ui.label(c, "EKTERNAL OVER LIMIT", 12f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        over.addView(ImageView(c).apply {
            setImageResource(R.drawable.logo)
            setOnClickListener { toast("RAM dibersihkan: ${Stats.cleanRam(c)} app") }
        }, LinearLayout.LayoutParams(d(56), d(32)))
        root.addView(over)
        return root
    }

    // ---------------- util ----------------
    private fun update() {
        fps = frames
        frames = 0
        val bat = Stats.batteryPct(this)
        batBar.progress = bat
        batTxt.text = "BAT $bat%"
        val rp = Stats.ramPercent(this)
        ramBar.progress = rp
        ramLabel.text = "RAM $rp%"
        gpuTv.text = "GPU ${Stats.gpuBusy()}"
        fpsTv.text = "FPS:$fps"
        ramTv.text = "RAM:${Stats.ramUsedMb(this)}"
        celTv.text = "CEL:${"%.1f".format(Stats.tempC(this))}°C"
        gauge?.let {
            it.value = fps / 120f
            it.invalidate()
        }
        gaugeTv?.text = "$fps fps"
    }

    private fun onOff(b: Boolean) = if (b) "ON" else "OFF"
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        Choreographer.getInstance().removeFrameCallback(frameCb)
        hidePanel2()
        panel1?.let { wm.removeView(it) }
        panel1 = null
        super.onDestroy()
    }
}
